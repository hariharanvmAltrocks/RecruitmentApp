import { Checkbox, ICheckboxStyles } from "@fluentui/react";
import * as React from "react";

interface viewProps {
    value?: boolean;
    onChange?: (key: string, value?: boolean, index?: number) => void;
    error?: boolean;
    disabled?: boolean;
    placeHolder?: string;
    label: string;
    mandatory?: boolean;
    fieldKey?: string;
}
const checkBoxStyles: ICheckboxStyles = {
    root: {
        ".ms-Checkbox-checkbox": {
            // height: "25px !important",
            // width: "25px !important",
            // borderRadius: "18%",
            border: "1px  ",
        },
        ":hover .ms-Checkbox-checkbox": {
            border: "2px solid  !important",
            background: "rgb(117 104 218)",
        },
        ":hover .ms-Checkbox-checkmark": {
            // color: "#ef3340",
        },
    },
};

function CustomCheckBox({
    value = false,
    label,
    disabled,
    fieldKey = "",
    error = false,
    mandatory = false,
    onChange,
}: viewProps) {
    return (
        <div>
            <Checkbox
                disabled={disabled}
                checked={value}
                onChange={
                    onChange ? (e, value) => onChange(fieldKey, value) : undefined
                }
                label={label}
                styles={checkBoxStyles}
            />
            {error && (
                <span style={{ color: "red", marginTop: "" }}>field is required</span>
            )}
        </div>
    );
}

export default CustomCheckBox;
