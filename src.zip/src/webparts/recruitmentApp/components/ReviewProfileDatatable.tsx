import * as React from "react";
import { DataTable } from "primereact/datatable";
import { Column } from "primereact/column";
import { TextField } from "office-ui-fabric-react";
import ReuseButton from "./ReuseButton";
import RefreshIcon from "@mui/icons-material/Refresh";
import { FilterMatchMode } from "primereact/api";
import { TabName } from "../utilities/Config";
import { Icon } from "@fluentui/react";

interface ColumnConfig {
  field: string;
  header: string | ((item?: any) => React.ReactNode);
  sortable: boolean;
  body?: (item?: any, index?: number, column?: ColumnConfig) => React.ReactNode;
  style?: React.CSSProperties;
}

interface SearchableDataTableProps {
  data: any[];
  columns: ColumnConfig[];
  rows: number;
  onPageChange: (event: any) => void;
  handleRefresh: () => void;
  totalItem?: number;
  pagination: { first: number; rows: number; totalPages: number };
  handleUploadCV?: () => void;
  UploadCV?: string;
}

const ReviewProfileDatatable: React.FC<SearchableDataTableProps> = ({
  data,
  columns,
  rows,
  onPageChange,
  handleRefresh,
  pagination,
  handleUploadCV,
  UploadCV,
}) => {
  const [filteredItems, setFilteredItems] = React.useState<any[]>(data);
  const [dashboardSearch, setDashboardSearch] = React.useState<any>({
    global: { value: null, matchMode: FilterMatchMode.CONTAINS },
  });
  const [totalItem, setTotalItem] = React.useState<number>(0);

  React.useEffect(() => {
    const PagewiseData =
      pagination.totalPages === 0
        ? data
        : data.slice(pagination.first, pagination.first + pagination.rows);
    setFilteredItems(PagewiseData);
    setTotalItem(data[0]?.TotalItems ?? data.length);
  }, [data]);

  const handleSearch = (event: React.ChangeEvent<HTMLInputElement>) => {
    const searchValue = event.target.value;

    setDashboardSearch({
      global: {
        value: searchValue,
        matchMode: FilterMatchMode.CONTAINS,
      },
    });

    const filtered = data.filter((item: any) =>
      Object.values(item).some((val) =>
        String(val).toLowerCase().includes(searchValue.toLowerCase())
      )
    );

    setFilteredItems(filtered);
  };

  return (
    // <CustomLoader isLoading={isLoading}>
    <div>
      <div className="ms-Grid-row">
        <div
          className="ms-Grid-col ms-lg9 search_div"
          style={{
            paddingLeft: "2%",
            position: "relative",
            display: "inline-block",
            height: "13px",
          }}
        >
          <TextField
            type="text"
            placeholder="Search..."
            styles={{
              fieldGroup: {
                borderRadius: "4px",
                boxShadow: "0px 0px 4px 4px rgba(0,0,0,.1)",
                borderColor: "#c9bdbd",
                height: "33px",
              },
            }}
            value={dashboardSearch.global.value}
            onChange={handleSearch}
          />
          <Icon
            iconName="Search"
            style={{
              fontSize: "20px",
              position: "absolute",
              top: "20%",
              right: "14px",
              color: "black",
            }}
          />
        </div>

        <div className="ms-Grid-col ms-lg1">
          <ReuseButton
            icon={
              <RefreshIcon
                style={{
                  fontSize: "38px",
                  marginTop: "1%",
                  marginLeft: "6%",
                  minWidth: "119px",
                  height: "30px",
                }}
              />
            }
            onClick={() => {
              setDashboardSearch({
                global: {
                  value: "",
                  matchMode: FilterMatchMode.CONTAINS,
                },
              });
              handleRefresh();
            }}
            spacing={4}
            Style={{ marginRight: "11px", minWidth: "100%", height: "31px" }}
          />
        </div>

        {UploadCV === TabName.UploadCV && (
          <div className="ms-Grid-col ms-lg1" style={{ marginLeft: "4%" }}>
            <ReuseButton
              label={UploadCV === TabName.UploadCV ? "Upload" : ""}
              onClick={handleUploadCV}
              spacing={4}
              // height="33px"
              // width="32%"
              Style={{ marginLeft: "-42px", minWidth: "100%", height: "31px" }}
            />
          </div>
        )}
      </div>
      <div className="ms-Grid-row" style={{ marginTop: "1%" }}>
        <div className="ms-Grid-col ms-lg12">
          <DataTable
            className="normalTable"
            value={filteredItems}
            lazy
            // rows={rows}
            rows={pagination.rows}
            first={pagination.first}
            totalRecords={totalItem}
            paginator
            rowsPerPageOptions={[5, 10, 20]}
            onPage={(event) => {
              onPageChange(event);
            }}
            paginatorTemplate="RowsPerPageDropdown FirstPageLink PrevPageLink CurrentPageReport NextPageLink LastPageLink"
            currentPageReportTemplate="{first} to {last} of {totalRecords}"
            stripedRows
            scrollable
            scrollHeight="35vh"
            paginatorDropdownAppendTo="self"
            // filters={dashboardSearch}
            onFilter={(e) => setFilteredItems(e.filteredValue || data)}
            style={{ overflow: "visible" }}
            emptyMessage="No Record Found"
          >
            {columns.map((col) => {
              return (
                <Column
                  key={col.field}
                  field={col.field}
                  header={col.header}
                  sortable={col.sortable}
                  body={col.body}
                  style={col.style}
                />
              );
            })}
          </DataTable>
        </div>
      </div>
      {/* <div className="ms-Grid-row" style={{ marginBottom: "2%" }}>
                    <div className="ms-Grid-col ms-lg6"></div>
                    <div
                        className="ms-Grid-col ms-lg6"
                        style={{ display: "flex", justifyContent: "end", marginLeft: "48%" }}
                    >
                        <div style={{ marginRight: "10px" }}>
                            <ReuseButton label="Submit" onClick={handleSubmit} spacing={4} />
                        </div>
                    </div>
                </div> */}
    </div>
    // </CustomLoader>
  );
};

export default ReviewProfileDatatable;
