
require("./Loader.module.css");
const styles = {
  customLoader: 'customLoader_293c31c4',
  s4: 's4_293c31c4'
};

export default styles;
