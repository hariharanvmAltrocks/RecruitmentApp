
require("./SideNavigation.module.css");
const styles = {
  sideNav: 'sideNav_ddb4c1af',
  imgBox: 'imgBox_ddb4c1af',
  linksContainer: 'linksContainer_ddb4c1af',
  navImg: 'navImg_ddb4c1af',
  navLabel: 'navLabel_ddb4c1af',
  active: 'active_ddb4c1af',
  navLine: 'navLine_ddb4c1af',
  activeSub: 'activeSub_ddb4c1af',
  navLineSelect: 'navLineSelect_ddb4c1af',
  navLabelChild: 'navLabelChild_ddb4c1af',
  expandnavImg: 'expandnavImg_ddb4c1af'
};

export default styles;
