import * as React from "react";
import "../App.css";
import { Stack } from "office-ui-fabric-react";
import CustomProfileComponent from "../components/CustomProfileComponent";

interface MainPageHeaderProps {
  children?: React.ReactNode;
  toggleSideNav: () => void;
  userName: string | undefined;
  userRole: string[] | undefined;
  Department: string | undefined;
}

const MainPageHeader: React.FC<MainPageHeaderProps> = ({
  children,
  toggleSideNav,
  userName,
  userRole,
  Department,
}) => {
  return (
    <div className="contentGrid">
      <div className="ContentHeader">
        <div className="ms-Grid-col ms-lg9">
          <Stack
            horizontal
            tokens={{ childrenGap: 15 }}
            style={{ alignItems: "right" }}
          >
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="31"
              height="31"
              viewBox="0 0 31 31"
              fill="none"
              onClick={toggleSideNav}
            >
              <path
                d="M2.45312 7.90625H24.7344C25.5366 7.90625 26.1875 7.25537 26.1875 6.45312C26.1875 5.65088 25.5366 5 24.7344 5H2.45312C1.65088 5 1 5.65088 1 6.45312C1 7.25537 1.65088 7.90625 2.45312 7.90625ZM24.7344 18.5625H12.1406C11.3384 18.5625 10.6875 19.2134 10.6875 20.0156C10.6875 20.8179 11.3384 21.4688 12.1406 21.4688H24.7344C25.5366 21.4688 26.1875 20.8179 26.1875 20.0156C26.1875 19.2134 25.5366 18.5625 24.7344 18.5625ZM24.7344 11.7812H12.1406C11.3384 11.7812 10.6875 12.4321 10.6875 13.2344C10.6875 14.0366 11.3384 14.6875 12.1406 14.6875H24.7344C25.5366 14.6875 26.1875 14.0366 26.1875 13.2344C26.1875 12.4321 25.5366 11.7812 24.7344 11.7812ZM2.45312 28.25H24.7344C25.5366 28.25 26.1875 27.5991 26.1875 26.7969C26.1875 25.9946 25.5366 25.3438 24.7344 25.3438H2.45312C1.65088 25.3438 1 25.9946 1 26.7969C1 27.5991 1.65088 28.25 2.45312 28.25ZM1.3209 15.9408L5.15957 12.1021C5.77109 11.4906 6.8125 11.9235 6.8125 12.7863V20.4606C6.8125 21.3234 5.76807 21.7563 5.15957 21.1448L1.32393 17.3092C0.942482 16.9308 0.94248 16.3192 1.3209 15.9408Z"
                fill="#597b98"
              />
            </svg>
            <h6 className="title">Recruitment Process</h6>
          </Stack>
        </div>
        <div
          className="ms-Grid-col ms-lg3"
          style={{ display: "flex", justifyContent: "end", marginTop: "-4%" }}
        >
          <CustomProfileComponent
            userName={userName}
            userRole={userRole}
            Department={Department}
          />
          {/* <div
            style={{
              display: "flex",
              width: "53%",
              flexDirection: "row",
              alignItems: "center",
              justifyContent: "center",
              backgroundColor: "white",
              borderRadius: "20px",
              padding: "5px",
              paddingLeft: "10px",
              paddingRight: "10px",
              boxShadow: "0px 5px 10px 0px #0F4B8426",
            }}
          >
            <AccountCircleIcon style={{ fontSize: 46 }} />

            <div>
              <p
                style={{
                  display: "flex",
                  alignItems: "center",
                  marginLeft: "5px",
                  color: "#0D547B",
                  fontWeight: "400",
                  fontSize: "12px",
                  marginTop: "5px",
                }}
              >
                Welcome,
                <p
                  style={{
                    fontWeight: "bold",
                    color: "#0D547B",
                  }}
                >
                  {userName}
                </p>
              </p>
              <div style={{ marginTop: "-9%" }}>
                <p
                  style={{
                    //display: "flex",
                    //alignItems: "center",
                    // margin: "5px",
                    fontWeight: "400",
                    fontSize: "12px",
                    marginLeft: "5px",
                    color: "#0D547B",
                  }}
                >
                  ({userRole} - {Department?.split("-")[1] ?? ""})
                </p>
              </div>
            </div>
          </div> */}
        </div>
      </div>
      <div className="MainContent " style={{ marginTop: "-1%" }}>
        {children}
      </div>
    </div>
  );
};

export default MainPageHeader;
